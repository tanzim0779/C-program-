const quizData = [
  {
    question: "Who is the creator of the website?",
    options: ["Tanzim Ahmmed", "Abdor Rahim", "Ayan", "Nayem Vai"],
    answer: 0,
    explanation: "The creator of this website is Tanzim Ahmmed."
  },
  {
    question: "What is the dream of Tanzim?",
    options: ["GSTU", "IUT", "BUET", "DU"],
    answer: 1,
    explanation: "Tanzim's dream is to study at IUT."
  },
  {
    question: "Will Tanzim be successful in his life?",
    options: ["Yes", "No", "Maybe", "Maybe not"],
    answer: 0,
    explanation: "Yes — with effort, learning, and persistence, Tanzim can work toward success."
  }
];

const questionsEl = document.getElementById("questions");
const form = document.getElementById("quiz-form");
const resultEl = document.getElementById("result");
const timerEl = document.getElementById("timer");
const submitBtn = document.getElementById("submit-btn");
const restartBtn = document.getElementById("restart-btn");

let remainingSeconds = 300;
let timerId = null;
let submitted = false;

function renderQuestions() {
  questionsEl.innerHTML = "";
  quizData.forEach((item, index) => {
    const card = document.createElement("article");
    card.className = "question-card";
    const title = document.createElement("h3");
    title.className = "question-title";
    title.innerHTML = `<span class="question-number">Q${index + 1}.</span>`;
    title.append(document.createTextNode(item.question));
    card.appendChild(title);

    item.options.forEach((option, optionIndex) => {
      const label = document.createElement("label");
      label.className = "option";
      const input = document.createElement("input");
      input.type = "radio";
      input.name = `question-${index}`;
      input.value = String(optionIndex);
      input.setAttribute("aria-label", option);
      const text = document.createElement("span");
      text.textContent = `${String.fromCharCode(65 + optionIndex)}. ${option}`;
      label.append(input, text);
      card.appendChild(label);
    });
    questionsEl.appendChild(card);
  });
}

function updateTimer() {
  const minutes = Math.floor(remainingSeconds / 60).toString().padStart(2, "0");
  const seconds = (remainingSeconds % 60).toString().padStart(2, "0");
  timerEl.textContent = `${minutes}:${seconds}`;
  if (remainingSeconds <= 0) {
    clearInterval(timerId);
    submitExam(true);
    return;
  }
  remainingSeconds -= 1;
}

function startTimer() {
  clearInterval(timerId);
  remainingSeconds = 300;
  updateTimer();
  timerId = setInterval(updateTimer, 1000);
}

function submitExam(timeUp = false) {
  if (submitted) return;
  submitted = true;
  clearInterval(timerId);

  let score = 0;
  let answered = 0;
  const cards = [...questionsEl.querySelectorAll(".question-card")];

  quizData.forEach((item, index) => {
    const chosen = form.querySelector(`input[name="question-${index}"]:checked`);
    if (chosen) answered++;
    const labels = cards[index].querySelectorAll(".option");

    labels.forEach((label, optionIndex) => {
      const input = label.querySelector("input");
      input.disabled = true;
      if (optionIndex === item.answer) label.classList.add("correct");
      if (chosen && Number(chosen.value) === optionIndex && optionIndex !== item.answer) {
        label.classList.add("incorrect");
      }
    });

    if (chosen && Number(chosen.value) === item.answer) score++;

    const explanation = document.createElement("p");
    explanation.className = "explanation";
    explanation.textContent = `Correct answer: ${String.fromCharCode(65 + item.answer)}. ${item.options[item.answer]} — ${item.explanation}`;
    cards[index].appendChild(explanation);
  });

  resultEl.classList.remove("hidden");
  resultEl.innerHTML = `<h3>${timeUp ? "Time is up!" : "Exam result"}</h3>
    <p><strong>Your score: ${score} / ${quizData.length}</strong></p>
    <p>Answered: ${answered} of ${quizData.length}</p>
    <p>${score === quizData.length ? "Excellent work!" : "Review the correct answers above and try again."}</p>`;
  submitBtn.disabled = true;
  resultEl.scrollIntoView({ behavior: "smooth", block: "start" });
}

form.addEventListener("submit", event => {
  event.preventDefault();
  submitExam(false);
});

restartBtn.addEventListener("click", () => {
  submitted = false;
  resultEl.classList.add("hidden");
  resultEl.innerHTML = "";
  submitBtn.disabled = false;
  renderQuestions();
  startTimer();
  window.scrollTo({ top: 0, behavior: "smooth" });
});

renderQuestions();
startTimer();


// Basic calculator
const cd = document.getElementById("calc-display");
const ch = document.getElementById("calc-history");
const cm = document.getElementById("calc-message");
let ci = "0", saved = null, op = null, fresh = false;
const fmt = n => Number.isFinite(n) ? String(Number.parseFloat(n.toPrecision(12))) : "Error";
function calc(a,b,o){ return o==="+"?a+b:o==="−"?a-b:o==="×"?a*b:o==="÷"?(b===0?null:a/b):b; }
function show(){ cd.textContent=ci; }
function clearCalc(){ ci="0";saved=null;op=null;fresh=false;ch.textContent="";cm.textContent="Calculator cleared.";show(); }
function equalsCalc(){
  if(op===null||saved===null)return;
  const a=saved,b=Number(ci),o=op,r=calc(a,b,o);
  ch.textContent=`${a} ${o} ${b} =`;
  if(r===null){ci="Cannot divide by zero";cm.textContent="Division by zero is not allowed.";}
  else {ci=fmt(r);cm.textContent="Calculation complete.";}
  saved=null;op=null;fresh=true;show();
}
document.querySelector(".calc-keys").addEventListener("click",e=>{
  const b=e.target.closest("button");if(!b)return;
  cm.textContent="";
  if(b.dataset.number!==undefined){
    const d=b.dataset.number;
    if(fresh||ci==="0"||ci==="Error"||ci==="Cannot divide by zero"){ci=d;fresh=false;}
    else if(ci.length<16)ci+=d;
    show();return;
  }
  const a=b.dataset.action;
  if(a==="clear"){clearCalc();return;}
  if(a==="backspace"){ci=(fresh||ci.length<=1||ci==="Error"||ci==="Cannot divide by zero")?"0":ci.slice(0,-1);fresh=false;show();return;}
  if(a==="decimal"){if(fresh){ci="0.";fresh=false;}else if(!ci.includes("."))ci+=".";show();return;}
  if(a==="sign"){if(Number(ci)!==0&&Number.isFinite(Number(ci)))ci=fmt(-Number(ci));show();return;}
  if(a==="percent"){if(Number.isFinite(Number(ci)))ci=fmt(Number(ci)/100);show();return;}
  if(a==="equals"){equalsCalc();return;}
  if(b.dataset.operator){
    const v=Number(ci);
    if(op!==null&&!fresh){const r=calc(saved,v,op);if(r===null){ci="Cannot divide by zero";saved=null;op=null;fresh=true;show();return;}ci=fmt(r);show();}
    saved=Number(ci);op=b.dataset.operator;ch.textContent=`${ci} ${op}`;fresh=true;
  }
});
